CLUTCH V2 phone-friendly prototype.
Includes: feed, friends, profile, create flow, local photo/video preview, drill discovery, categories, random drill, likes, and progress UI.
Important: this prototype stores new posts only in the current browser session. Real shared accounts, cloud video storage, cross-device feeds, friend relationships, comments, and persistent profiles require a backend connection such as Supabase. The drill section is a starter catalog; external video discovery/embedding requires appropriate video-provider access and permissions.
